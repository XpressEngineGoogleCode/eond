
	function selLanguage(id) {
		var get = document.getElementById(id);
		if (get.style.display == 'block')
		{
			get.style.display = 'none';
		}
		else
		{
			get.style.display = 'block';
		}
	}