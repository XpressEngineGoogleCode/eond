/* 
 * wrapScroll
 * Copyright 2007 youmos <youmos.com@gmail.com>
 * http://youmos.com/project/wrapscroll
 * 
 * The wrapScroll is licensed under a 
 * Creative Commons Attribution-NonCommercial-NoDerivs License.
 *
 * http://creativecommons.org/licenses/by-nc-nd/3.0/
 *
 * It is provided "as is" and without warranty of any kind. If you wish to continue to use it,
 * free for personal or non-commercial use, $30 for commercial use,
 * or transform and build your script upon this work to distribute.
 * The permission is valid for all future versions of wrapScroll.
*/

/*--- wrapscroll.js ---*/
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('7 m=2(){1.B.C(1,D)};m.E={X:\'0.9.6\',F:Y,h:Z,n:0,G:0,i:0,q:H,B:2(e,p,r){1.I(11,\'12\',1.u(1.J,D))},J:2(e,p,r){3(o=8.w(e)){1.q={\'e\':o,\'p\':(p)?8.w(p):o.13,\'r\':(r)?8.w(r):H};o.4.K=\'L\';3((c=o.g)!=(v=((o.4.j=o.g+\'x\')!=\'\')?o.g:0)){o.4.n=0;o.4.j=c+(v-c)+\'x\'}1.z()}},z:2(){f=1.M.N(1,1.q);14(1.u(1.z),(f)?10:1.F)},u:2(a,b){7 c=1;7 d=(b)?b:[];5 2(){a.C(c,d)}},I:2(e,a,b,c){3(e.O){e.O(a,b,c)}15 3(e.P){e.P(\'16\'+a,b)}},17:2(f,d){3(f){1.A=f}3(d){1.h=d}},A:2(t,b,c,d){5 c*(t/=d)*t+b}};m.E.M={N:2(t,o){7 a=Q.18(1.R(),(o.r)?1.k(o.r)+1.l(o.r):1.k(o.p));7 b=(1.k(o.p)+1.l(o.p))-(1.l(o.e)+t.G);7 s=19(o.e.4.j);7 e=Q.1a(b,a+t.n);3((t.S!=e)||(t.i>t.h)){t.i=0}3((t.S=e)!=s){o.e.4.j=t.A(t.i++,s,e-s,t.h,o.e.4)+\'x\';5 1b}5 1c},R:2(){5 8.T.U||8.V.U},l:2(o){5 o.1d||8.V.W||8.T.W},k:2(o){y=o.g;3(o.4.K==\'L\'){5 y};1e(o=o.1f){y+=o.g}5 y}};',62,78,'|this|function|if|style|return||var|document||||||||offsetTop|Duration|_timer|top|offset|height|wrapScroll|marginTop|||_obj||||bind||getElementById|px||callback|tween|initialize|apply|arguments|prototype|Interval|marginBottom|null|attach|prepare|position|absolute|event|update|addEventListener|attachEvent|Math|scroll|_prev|documentElement|scrollTop|body|scrollHeight|Version|500|60||window|load|parentNode|setTimeout|else|on|setTween|max|parseInt|min|true|false|offsetHeight|while|offsetParent'.split('|'),0,{}))
