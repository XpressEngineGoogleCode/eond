<?php
		$lang->login_message = '<b>%s</b>님, 환영합니다.';
    $lang->login = '로그인';
    $lang->logout = '로그아웃';
    $lang->myinfo = '회원정보';
    $lang->join = '회원가입';
    $lang->manage = '제어판';
    $lang->Elkha = '엘카';
    $lang->usr_id = '아이디';
    $lang->my_id = '내 아이디';
    $lang->open_id = '오픈 아이디'
?>
