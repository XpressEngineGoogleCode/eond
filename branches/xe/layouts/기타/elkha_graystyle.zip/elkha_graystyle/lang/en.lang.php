<?php
		$lang->login_message = 'Welcomes you, <b>%s</b>';
    $lang->login = 'Login';
    $lang->logout = 'Logout';
    $lang->myinfo = 'Profile';
    $lang->join = 'Join';
    $lang->manage = 'Control pannel';
    $lang->usr_id = 'Account';
    $lang->my_id = 'My ID';
    $lang->open_id = 'Open ID'
?>
