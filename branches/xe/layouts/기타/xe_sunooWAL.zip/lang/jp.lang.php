<?php
  $lang->sl_point = 'ポイント';
  $lang->sl_management = '管理';
  $lang->sl_related_site = '?連サイト';
	$lang->sl_favorites = 'お?に入り';
  
  $lang->sl_show_lang = '言語の選?';
  $lang->sl_show_login = 'ログイン';
  $lang->sl_show_join = '?員登?';
  $lang->sl_show_id = 'してくださいIDを入力します。';
  $lang->sl_show_pw = 'あなたのパスワ?ドを入力します。';
  $lang->sl_show_search = '?索用語を入力してください。';
  $lang->sl_show_top = '頂上';
  
?>