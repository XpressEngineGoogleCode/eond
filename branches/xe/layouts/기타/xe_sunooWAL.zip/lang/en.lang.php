<?php
  $lang->sl_point = 'point';
  $lang->sl_management = 'management';
  $lang->sl_related_site = 'related site';
	$lang->sl_favorites = 'Favorites';
  
  $lang->sl_show_lang = 'Select Language';
  $lang->sl_show_login = 'Login';
  $lang->sl_show_join = 'Join';
  $lang->sl_show_id = 'Please enter the ID.';
  $lang->sl_show_pw = 'Please enter your password.';
  $lang->sl_show_search = 'Enter your search terms.';
  $lang->sl_show_top = 'Top';

?>