<?php
  $lang->sl_point = '點';
  $lang->sl_management = '管理';
  $lang->sl_related_site = '相關網站';
	$lang->sl_favorites = '我的最愛';
  
  $lang->sl_show_lang = '選擇語言';
  $lang->sl_show_login = '註冊';
  $lang->sl_show_join = '加入';
  $lang->sl_show_id = '請輸入身?證。';
  $lang->sl_show_pw = '請輸入?的密碼。';
  $lang->sl_show_search = '輸入?的搜索字詞。';
  $lang->sl_show_top = '頂端';
  
?>