<?php
  $lang->sl_point = '포인트';
  $lang->sl_management = '설정·관리';
  $lang->sl_related_site = '= 관련 사이트 =';
  $lang->sl_favorites = '즐겨찾기추가';
  
  $lang->sl_show_lang = '언어선택';
  $lang->sl_show_login = '로그인';
  $lang->sl_show_join = '회원가입';
  $lang->sl_show_id = '아이디를 입력하세요.';
  $lang->sl_show_pw = '비밀번호를 입력하세요.';
  $lang->sl_show_search = '검색어를 입력하세요.';
  $lang->sl_show_top = '위로';
  
	
?>