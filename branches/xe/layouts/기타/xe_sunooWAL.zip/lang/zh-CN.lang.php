<?php
  $lang->sl_point = '点';
  $lang->sl_management = '管理';
  $lang->sl_related_site = '相??站';
	$lang->sl_favorites = '我的最?';
  
  $lang->sl_show_lang = '???言';
  $lang->sl_show_login = '注?';
  $lang->sl_show_join = '加入';
  $lang->sl_show_id = '??入身??。';
  $lang->sl_show_pw = '??入?的密?。';
  $lang->sl_show_search = '?入?的搜索字?。';
  $lang->sl_show_top = '?端';
  
?>