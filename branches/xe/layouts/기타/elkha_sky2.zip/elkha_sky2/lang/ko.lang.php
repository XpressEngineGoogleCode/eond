<?php
		$lang->login_message = '<b>%s</b>님, 환영합니다.';
    $lang->login = '로그인';
    $lang->logout = '로그아웃';
    $lang->myinfo = '회원정보';
    $lang->join = '회원가입';
    $lang->manage = '제어판';
    /* $lang->select_lang = '언어 설정'; */
?>
